HeartMeet Launcher Icons & Splash Preview


Included files:
- icons/ic_launcher_<size>.png  (various sizes)
- splash_preview.png

How to integrate:
1. Copy the PNGs into your Android project under app/src/main/res/mipmap-<density>/
   or mipmap-anydpi-v26 for adaptive icons.
2. Replace existing ic_launcher files with these PNGs, or update adaptive-icon XML to use ic_heart_foreground.
3. The splash_preview.png is a visual sample for the splash screen background.

If you want, I can directly place these into your GitHub-ready project before you push.
